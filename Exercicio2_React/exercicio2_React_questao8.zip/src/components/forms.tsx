function Forms(props: any) {
    return (
        <form>
            {props.children}
        </form>
    )
};

export default Forms