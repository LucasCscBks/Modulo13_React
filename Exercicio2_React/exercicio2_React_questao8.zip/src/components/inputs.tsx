function InputName(props: any) {
    return (
        <input type={props.type}/>
    )
}

function InputPassword(props: any) {
    return (
        <input type={props.type}/>
    )
}

export {InputName, InputPassword}