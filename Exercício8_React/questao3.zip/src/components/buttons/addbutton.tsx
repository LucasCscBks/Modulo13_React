
function ButtonAddProduct(props: any) {
    return (
        <button onClick={props.func} type="button"> Adicionar produto</button>
    )
}

export default ButtonAddProduct