function ButtonProducts(props: any) {
    return (
        <button onClick={props.func} type="button"> Mostrar produtos</button>
    )
    
}

export default ButtonProducts