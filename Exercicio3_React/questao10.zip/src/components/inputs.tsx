function InputEmail(props: any) {
    return (
        <input name="email" type={props.type} placeholder="Email" required/>
    )
}

function InputName(props: any) {
    return (
        <input name="name" type={props.type} placeholder="Name" required/>
    )
}

function InputPassword(props: any) {
    return (
        <input name="password" type={props.type} placeholder="Password" required/>
    )
}

export {InputEmail, InputName, InputPassword}