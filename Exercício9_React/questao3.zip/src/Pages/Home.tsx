export default function Home() {
    return (
        <div>Bem vindo a HOME</div>
    )
}