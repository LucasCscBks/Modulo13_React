export default function ErrorPage() {
    return (
        <div> Error! Page not found!</div>
    )
}