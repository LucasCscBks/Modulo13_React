import styled from "styled-components"

export const StyledLabel = styled.label`
  font-size: 18px;
  color: rgba(0,0,255,1)
`